# Catz

This Zendesk app displays cat gifs in the ticket sidebar.

Please submit bug reports to [Niall](mailto:ncolfer@zendesk.com). Pull requests are welcome.